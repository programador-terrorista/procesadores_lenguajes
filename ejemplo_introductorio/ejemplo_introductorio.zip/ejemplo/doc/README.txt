//*****************************************************************
// File:   HellowWorld.java
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   febrero 2022
// Coms:   Compilar mediante "ant"
//         Ejemplo de uso de javacc para genera un analizador léxico
//         e integrarlo en un programa externo. Toma datos de la 
//         entrada estándar. Identifica tokens, y opera con algunos de ellos.
//         Hay ficheros de prueba en "doc/ejemplos"
//*****************************************************************
